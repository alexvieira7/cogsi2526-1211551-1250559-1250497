package basic_demo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DemoTest {

     @Test
     void demoRuns()
     {
        assertTrue(true, "Sample  test to check Gradle setup");
     }

}
